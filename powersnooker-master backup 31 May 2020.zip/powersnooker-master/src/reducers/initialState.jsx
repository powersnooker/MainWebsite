export default {
  pages: [],
  globals: {},
  widgets: [],
  members: [],
  formsState: {},
};
