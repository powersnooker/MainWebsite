import * as types from '../actions/actionTypes.jsx';
import initialState from './initialState.jsx';

export default function pagesReducer(state = initialState.pages, action) {
  switch (action.type) {
    case types.LOAD_PAGES_SUCCESS:
      return action.pages;
    default:
      return state;
  }
}
