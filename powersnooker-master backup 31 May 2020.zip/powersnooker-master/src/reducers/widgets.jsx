
import * as types from '../actions/actionTypes.jsx';
import initialState from './initialState.jsx';

export default function pagesReducer(state = initialState.widgets, action) {
  switch (action.type) {
    case types.LOAD_WIDGETS_SUCCESS:
      return action.widgets;
    default:
      return state;
  }
}
