import * as types from '../actions/actionTypes.jsx';
import initialState from './initialState.jsx';

export default function globalsReducer(state = initialState.globals, action) {
  switch (action.type) {
    case types.LOAD_GLOBALS_SUCCESS:
      return action.globals;
    default:
      return state;
  }
}
