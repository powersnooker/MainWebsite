import * as types from '../actions/actionTypes.jsx';
import initialState from './initialState.jsx';

export default function globalsReducer(state = initialState.formsState, action) {
  switch (action.type) {
    case types.LOAD_FORMS_SUCCESS:
      return action.formsState;
    default:
      return state;
  }
}
