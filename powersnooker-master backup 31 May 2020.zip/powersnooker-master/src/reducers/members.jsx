import * as types from '../actions/actionTypes.jsx';
import initialState from './initialState.jsx';

export default function membersReducer(state = initialState.members, action) {
  switch (action.type) {
    case types.LOAD_MEMBERS_SUCCESS:
      return action.members;
    default:
      return state;
  }
}
