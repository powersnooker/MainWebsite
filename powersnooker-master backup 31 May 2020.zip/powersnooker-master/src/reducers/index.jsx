
import { combineReducers } from 'redux';
import pages from './pages.jsx';
import globals from './globals.jsx';
import widgets from './widgets.jsx';
import members from './members.jsx';
import forms from './forms.jsx';

const rootReducer = combineReducers({
  // short hand property names
  pages,
  globals,
  widgets,
  members,
  forms,
});

export default rootReducer;
