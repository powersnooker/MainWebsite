import React, { Component } from 'react';

import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { PageList } from '../components/pages/pages.jsx';
import GDPR from '../components/gdpr/gdpr.jsx';

import * as actions from '../actions/pages.jsx';


class NavContainer extends Component {
  componentWillMount() {
    this.props.actions.loadAllPages();
    this.context.store.subscribe(() => {
      this.handlePageChange = this.handlePageChange.bind(this);
    });
  }

  handlePageChange(url) {
    this.context.router.history.push(url);
  }


  render() {
    const { pages } = this.props;
    return (
      <nav className="navbar navbar-expand-lg">
        <GDPR />
        <PageList pages={pages} handlePageChange={this.handlePageChange} />
      </nav>
    );
  }
}

NavContainer.propTypes = {
  actions: PropTypes.object,
  pages: PropTypes.array,
};

NavContainer.defaultProps = {
  actions: () => {},
  pages: [],
};

const mapStateToProps = (state) => {
  return {
    pages: state.pages,
  };
};

const mapDispatchToProps = (dispatch) => {
  return { actions: bindActionCreators(actions, dispatch) };
};

NavContainer.contextTypes = {
  store: React.PropTypes.object,
  router: React.PropTypes.shape({
    history: React.PropTypes.object.isRequired,
  }),
};

export default connect(mapStateToProps, mapDispatchToProps)(NavContainer);
