import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Header } from '../components/header/Header.jsx';

import * as actions from '../actions/globals.jsx';
import * as widgetsActions from '../actions/widgets.jsx';
import * as membersActions from '../actions/members.jsx';

class HeaderContainer extends Component {
  componentWillMount() {
    this.props.actions.globals.loadAllGlobals();
    this.props.actions.widgets.loadAllWidgets();
    this.props.actions.members.loadAllMembers();
  }

  render() {
    const { headerItems } = this.props;
    return (
      <div>
        <Header items={headerItems} />
      </div>
    );
  }
}

HeaderContainer.propTypes = {
  actions: PropTypes.object,
  headerItems: PropTypes.object,
};

HeaderContainer.defaultProps = {
  actions: () => {},
  headerItems: {},
};

const mapStateToProps = (state) => {
  return {
    headerItems: state.globals,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    actions: {
      globals: bindActionCreators(actions, dispatch),
      widgets: bindActionCreators(widgetsActions, dispatch),
      members: bindActionCreators(membersActions, dispatch),
    },
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(HeaderContainer);
