import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import * as actions from '../actions/members.jsx';
import { MembersComp } from '../components/members/listings.jsx';

class MembersContainer extends Component {
  componentWillMount() {
    this.props.actions.loadAllMembers();
  }

  render() {
    const { members, headings } = this.props;
    return (
      <div>
        <MembersComp items={members} headings={headings} />
      </div>
    );
  }
}

MembersContainer.propTypes = {
  actions: PropTypes.object,
  members: PropTypes.array,
  headings: PropTypes.object,
};

MembersContainer.defaultProps = {
  actions: () => {},
  members: [],
};

const mapStateToProps = (state) => {
  return {
    members: state.members,
  };
};

const mapDispatchToProps = (dispatch) => {
  return { actions: bindActionCreators(actions, dispatch) };
};

export default connect(mapStateToProps, mapDispatchToProps)(MembersContainer);
