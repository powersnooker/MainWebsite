import React, { Component, PropTypes } from 'react';
import { Page } from '../components/page/page.jsx';
import MembersContainer from './membersContainer.jsx';
// import { ServicesComp } from '../components/services/listings.jsx';

export class PageContainer extends Component {
  constructor(props) {
    super(props);
    this.state = { selectedPage: [], pages: [] };
  }

  componentDidMount() {
    document.body.scrollTop = document.documentElement.scrollTop = 0;
    this.context.store.subscribe(() => {
      this.setState({
        selectedPage: this.getSelectedPage(this.context.store.getState().pages,
          this.props.match.params.name),
        pages: this.context.store.getState().pages,
      });
    });
  }

  componentWillReceiveProps(nextProps) {
    document.body.scrollTop = document.documentElement.scrollTop = 0;
    if (this.props.match.params.name !== nextProps.match.params.name) {
      this.setState({
        selectedPage: this.getSelectedPage(this.state.pages, nextProps.match.params.name),
      });
    }
  }

  getSelectedPage(pages, url) {
    const pageSelected = pages.filter((page) => {
      return page.url === url;
    });
    return pageSelected;
  }

  printSelectedPage() {
    let selectedPage = this.getSelectedPage(this.context.store.getState().pages,
      this.props.match.params.name);
    if (selectedPage.length > 0) {
      selectedPage = <Page selected={selectedPage[0]} widgets={this.state.widgets} />;
    }

    return selectedPage;
  }

  printExtras() {
    const selectedPage = this.getSelectedPage(this.context.store.getState().pages,
      this.props.match.params.name);
    let extras = '';
    if (selectedPage.length > 0) {
      switch (this.props.match.params.name) {
        case 'ThePowerSnookerGroup':
          extras = <MembersContainer headings={selectedPage[0].membersHeading} />;
          break;
        case 'psc':
          // extras = <ServicesComp items={selectedPage[0].widgets} />;
          break;
        default:
          break;
      }
    }

    return extras;
  }

  render() {
    return (
      <div>
        {this.printSelectedPage()}
        {this.printExtras()}
      </div>
    );
  }
}

PageContainer.propTypes = {
  match: PropTypes.object.isRequired,
  history: PropTypes.object.history,
};

PageContainer.contextTypes = {
  store: React.PropTypes.object,
};
