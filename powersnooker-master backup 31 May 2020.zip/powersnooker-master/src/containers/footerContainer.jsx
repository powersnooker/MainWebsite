import React, { Component } from 'react';

import { Footer } from '../components/footer/footer.jsx';

class FooterContainer extends Component {
  constructor(props) {
    super(props);
    this.state = { globals: {}, services: [], pages: [], people: [] };
  }

  componentDidMount() {
    this.context.store.subscribe(() => {
      this.setState({
        globals: this.context.store.getState().globals,
        services: this.context.store.getState().services,
        pages: this.context.store.getState().pages,
        people: this.context.store.getState().members,
      });
    });
  }

  render() {
   // const { services } = this.props;
    return (
      <footer className="main-footer">
        <Footer
          extraInfo={this.state.globals}
          services={this.state.services}
          pages={this.state.pages}
          people={this.state.people}
        />
      </footer>
    );
  }
}

FooterContainer.contextTypes = {
  store: React.PropTypes.object,
};

export default FooterContainer;
