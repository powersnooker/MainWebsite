import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as memberActions from '../actions/members.jsx';
import { MembersComp } from '../components/members/listings.jsx';
import { TopPages } from '../components/topPages/topPages.jsx';
import { Widgets } from '../components/widgets/widgets.jsx';
import { ServicesComp } from '../components/services/listings.jsx';
import { VideosComp } from '../components/videos/listings.jsx';
import Banner from '../components/banner/banner.jsx';

class HomeContainer extends Component {
  componentWillMount() {
    document.body.scrollTop = document.documentElement.scrollTop = 0;
  }

  render() {
    const { members, topPages, page } = this.props;
    const home = true;
    return (
      <div className="home">
        <TopPages pages={topPages} />
        <Widgets
          items={page.widgets.length > 0 ? page.widgets : []}
          pageName="home"
          headings={page.widgetsHeading}
        />
        <Banner banner={page.banner1} />
        <ServicesComp
          items={page.widgets}
          headings={page.servicesHeadings}
        />
        <Banner banner={page.banner2} />
        <VideosComp
          items={page.widgets.length > 0 ? page.widgets : []}
          headings={page.productsHeadings}
        />
        <MembersComp
          items={members.length > 0 ? members : []}
          isHome={home} headings={page.membersHeading}
        />
      </div>
    );
  }
}

HomeContainer.propTypes = {
  actions: PropTypes.object,
  members: PropTypes.array,
  topPages: PropTypes.array,
  page: PropTypes.object,
};

HomeContainer.defaultProps = {
  actions: () => { },
  members: [],
  topPages: [],
  page: {
    widgets: [],
    banner1: null,
    banner2: null,
  },
  pages: {},
};

const mapStateToProps = (state) => {
  return {
    members: state.members,
    topPages: state.pages.filter((page) => {
      return page.displayAtHomepage;
    }),
    page: state.pages.filter((page) => {
      return page.title === 'Home';
    })[0],
  };
};

const mapDispatchToProps = (dispatch) => {
  return { actions: bindActionCreators(memberActions, dispatch) };
};

export default connect(mapStateToProps, mapDispatchToProps)(HomeContainer);
