import React from 'react';
import { Router, Route } from 'react-router-dom';
import { createBrowserHistory } from 'history';
import NavContainer from './navContainer.jsx';
import { PageContainer } from './pageContainer.jsx';
import HeaderContainer from './headerContainer.jsx';
import { SearchContainer } from './searchContainer.jsx';
import FooterContainer from './footerContainer.jsx';
import HomeContainer from './homeContainer.jsx';

const history = createBrowserHistory();

class App extends React.Component {
  constructor(p, c) {
    super(p, c);
    this.state = { color: 'blue' };
  }

  render() {
    return (
      <Router history={history}>
        <div>
          <nav className="header-1">
            <HeaderContainer />
            <NavContainer />
          </nav>
          <div className="main-container">
            <Route exact path="/" component={HomeContainer} />
            <Route path="/search/:key" component={SearchContainer} />
            <Route
              path="/:name" render={(props) => (
                props.match.params.name !== 'home'
                  ? <PageContainer {...props} />
                  : <HomeContainer {...props} />
              )}
            />
            <FooterContainer />
          </div>
        </div>
      </Router>
    );
  }
}
export default App;
