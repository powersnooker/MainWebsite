import * as contentful from 'contentful';

class ApiClient {
  constructor() {
    this._client = contentful.createClient({
      space: 'qvknk0ucelq0',
      accessToken: '040b6df95fc64779acd18ce75ba30ebbfc62275125a3979ed0a9cc9146e34246',
    });
  }

  getClientInstance(id) {
    return this._client.getEntries({
      content_type: id,
    })
    .then((entries) => {
      return entries.items;
    });
  }
}

export default new ApiClient();
