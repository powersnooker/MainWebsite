class EmailClient {
  constructor() {
    this._client = './email.php';
  }

  sendData(data, emailTo) {
    const myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/x-www-form-urlencoded');
    return fetch(this._client, {
      method: 'POST',
      headers: myHeaders,
      mode: 'cors',
      cache: 'default',
      body: `body=${data.body}&type=${data.type}&sendto=${emailTo}
      &name=${data.name}&surname=${data.surname}&email=${data.email}`,
    }).then((response) => {
      return response.json();
    });
  }
}

export default new EmailClient();
