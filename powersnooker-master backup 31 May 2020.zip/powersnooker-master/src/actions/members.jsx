import * as types from './actionTypes.jsx';
import ApiClient from '../api/apiClient.jsx';

export function loadMembersSuccess(members) {
  return { type: types.LOAD_MEMBERS_SUCCESS, members };
}

export function loadAllMembers() {
  // make async call to api, handle promise, dispatch action when promise is resolved
  return (dispatch) => {
    ApiClient.getClientInstance('boardMembers').then(members => {
      const membersObj = members.sort((a, b) => {
        return a.fields.order - b.fields.order;
      });

      return dispatch(loadMembersSuccess(membersObj));
    });
  };
}
