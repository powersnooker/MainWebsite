import * as types from './actionTypes.jsx';
import ApiClient from '../api/apiClient.jsx';

export function loadWidgetsSuccess(widgets) {
  return { type: types.LOAD_WIDGETS_SUCCESS, widgets };
}

export function loadAllWidgets() {
  // make async call to api, handle promise, dispatch action when promise is resolved
  return (dispatch) => {
    ApiClient.getClientInstance('widgets').then(widgets => {
      return dispatch(loadWidgetsSuccess(widgets));
    });
  };
}
