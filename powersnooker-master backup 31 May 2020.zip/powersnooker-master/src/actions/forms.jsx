import * as types from './actionTypes.jsx';
import EmailClient from '../api/emailClient.jsx';

export function loadSendSuccess(formsState) {
  return { type: types.LOAD_FORMS_SUCCESS, formsState };
}

export function sendData(formsData, email) {
  return (dispatch) => {
    EmailClient.sendData(formsData, email).then((response) => {
      return dispatch(loadSendSuccess(response));
    });
  };
}
