import * as types from './actionTypes.jsx';
import ApiClient from '../api/apiClient.jsx';

export function loadGlobalsSuccess(globals) {
  return { type: types.LOAD_GLOBALS_SUCCESS, globals };
}

export function loadAllGlobals() {
  // make async call to api, handle promise, dispatch action when promise is resolved
  return (dispatch) => {
    ApiClient.getClientInstance('generalInfoItems')
    .then(globals => {
      const globalsObj = globals.reduce((acc, global) => {
        acc[global.fields.name] = { link: global.fields.link, value: global.fields.value };
        return acc;
      }, {});
      return dispatch(loadGlobalsSuccess(globalsObj));
    });
  };
}
