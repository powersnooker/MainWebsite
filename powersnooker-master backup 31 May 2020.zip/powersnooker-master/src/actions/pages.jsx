import * as types from './actionTypes.jsx';
import ApiClient from '../api/apiClient.jsx';

export function loadPagesSuccess(pages) {
  return { type: types.LOAD_PAGES_SUCCESS, pages };
}

export function loadAllPages() {
  // make async call to api, handle promise, dispatch action when promise is resolved
  return (dispatch) => {
    ApiClient.getClientInstance('page').then(pages => {
      let pagesObj = pages.map((page) => {
        return page.fields;
      }, {});

      pagesObj = pagesObj.sort((a, b) => {
        return a.orderOnTopMenu - b.orderOnTopMenu;
      });

      pagesObj.forEach(page => {
        if (!Object.prototype.hasOwnProperty.call(page, 'subpages')) {
          page.subpages = [];
        }
      });

      return dispatch(loadPagesSuccess(pagesObj));
    });
  };
}
