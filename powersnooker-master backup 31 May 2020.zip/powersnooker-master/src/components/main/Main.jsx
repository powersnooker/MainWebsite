// Dependencies
import React from 'react';

// Components
import Header from '../header/Header.jsx';

// Styles
import './Main.scss';

const Main = function () {
  return (
    <div className="row">
      <Header />
      <div className="col-xs-10 align-center">
        <div className="row">
          <div className="col-xs-10">
            test32
          </div>
          <div className="col-xs-2">
           test344
          </div>
        </div>
      </div>
    </div>
  );
};

export default Main;
