import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import Main from '../Main';

describe("component/Main", () => {
  it('should mount', () => {
    const comp = shallow(
      <Main />
    );

    expect(comp.find('div').length).to.be.least(1);
  });
});
