import React, { PropTypes, Component } from 'react';
import mjaclogo from '../../assets/images/mjac.png';
import advfn from '../../assets/images/advfn.png';

import './footer.scss';

export class Footer extends Component {
  printServices() {
    const items = this.props.services;
    return (
      items.map(item =>
        <li> <a href="/practise-areas"> {item.name}</a></li>
      )
    );
  }

  printPeople() {
    const items = this.props.people;
    return (
      items.map(item =>
        <li> <a href="/lawyers"> {item.Name} {item.Surname}</a></li>
      )
    );
  }

  printExtraInfo() {
    // const items = this.props.extraInfo;
    return (
      <div className="row">
        <div className="col-xs-12 col-lg-12">
          Opening Hours:&nbsp;
            {/* <span
            dangerouslySetInnerHTML={{ __html: items.openinghours }}
          /> */}
        </div>
      </div>
    );
  }

  render() {
    return (
      <footer className="footer">
        <div className="footer-pri">
          <div className="container">
            <div className="row">
              <div className="col-lg-7 footer-widget">
                <h5 className="heading text-white">
                  Quick <span className="text-primary">Links</span>
                </h5>
                <ul className="quick-links">
                  <li><a href="termsandcondition">Terms and Conditions</a></li>
                  <li><a href="policy">Privacy Policy</a></li>
                </ul>
              </div>
              <div className="col-lg-5 footer-widget partners-container">
                <div className="partners-heading">
                  <h5 className="heading text-white ">
                    In association <span className="text-primary">with</span>
                  </h5>
                  <ul className="partners text-right">
                    <li><a className="navbar-brand" href="//uk.advfn.com/">
                      <img src={advfn} alt="" />
                    </a>
                    </li>
                    <li><a className="navbar-brand" href="//mjac.io/">
                      <img src={mjaclogo} alt="" />
                    </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="footer-sec">
          <div className="container-fluid">
            <div className="row">
              <div className="col-lg-6 text-right">
                <span className="copyright">
                  COPYRIGHT © 2017 - POWER SNOOKER GROUP LIMITED. ALL RIGHTS RESERVED.
                </span>
              </div>
              <div className="col-lg-2">
                <span>
                  <a href="https://www.contentful.com/" rel="nofollow">
                    <img
                      className="contentful"
                      src="https://images.contentful.com/fo9twyrwpveg/44baP9Gtm8qE2Umm8CQwQk/c43325463d1cb5db2ef97fca0788ea55/PoweredByContentful_LightBackground.svg"
                      alt="Powered by Contentful"
                    />&nbsp;
                  </a>
                </span>
              </div>
              <div className="col-lg-4">
                <ul className="social justify-content-center">
                  <li><a href="https://www.facebook.com/officialpowersnooker/"><i className="fa fa-facebook" /></a></li>
                  <li><a href="https://twitter.com/powersnookeruk"><i className="fa fa-twitter" /></a></li>
                  <li><a href="https://www.instagram.com/powersnooker/"><i className="fa fa-instagram" /></a></li>
                  <li><a href="https://www.linkedin.com/company/officialpowersnooker/"><i className="fa fa-linkedin" /></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </footer>
    );
  }
}

Footer.propTypes = {
  services: PropTypes.array,
  pages: PropTypes.array,
  extraInfo: PropTypes.object,
  people: PropTypes.array,
};

export default Footer;
