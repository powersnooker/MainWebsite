// Dependencies
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { TopBar } from '../topbar/topbar.jsx';

// Styles
import './Header.scss';

export class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {
      items: props.items,
    };
  }

  render() {
    return (
      <div>
        <TopBar items={this.props.items} />
      </div>
    );
  }
}

Header.propTypes = {
  items: PropTypes.object.isRequired,
};

export default Header;
