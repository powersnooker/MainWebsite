import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import Header from '../Header';

describe("component/Header", () => {
  it('should mount', () => {
    const comp = shallow(
      <Header />
    );

    expect(comp.find('div').length).to.be.least(1);
  });
});
