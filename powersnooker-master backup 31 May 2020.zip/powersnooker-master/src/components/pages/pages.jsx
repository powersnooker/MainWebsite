import React, { PropTypes, Component } from 'react';
import { Link, withRouter } from 'react-router-dom';

import './pages.scss';
import logo from '../../assets/images/logo.png';

export class PageList extends Component {
  constructor(prop) {
    super(prop);
    this.openNav = this.openNav.bind(this);

    this.state = {
      open: true,
    };
  }

  componentWillMount() {
    this.setState({
      open: !this.state.open,
    });
  }

  openNav() {
    this.setState({
      open: !this.state.open,
    });
  }

  handleSearch(event) {
    this.props.handlePageChange(`/search/${event}`);
  }

  createSubpages(subpages) {
    let returnVal = '';

    if (subpages.length > 0) {
      returnVal = (
        <div className="sub-menu">
          <ul className="menu-list">
            {subpages.map(subpage =>
              <li>
                {this.createLink(subpage.fields)}
              </li>
            )}
          </ul>
        </div>
      );
    }

    return returnVal;
  }

  createLink(page) {
    let returnLink = (typeof page !== 'undefined') ? (
      <Link
        className="nav-link"
        onClick={this.openNav}
        to={`/${page.url}`}
      >
        {page.title}
      </Link>
    ) : '';

    if (typeof page !== 'undefined') {
      if (Object.prototype.hasOwnProperty.call(page, 'isredirect')) {
        if (page.isredirect) {
          returnLink = (<a
            className="nav-link"
            href={page.redirecturl}
          >
            {page.title}
          </a>);
        }
      }

      if (!Object.prototype.hasOwnProperty.call(page, 'isredirect')) {
        if (!page.isredirect) {
          returnLink = (
            <Link
              className="nav-link"
              onClick={this.openNav}
              to={`/${page.url}`}
            >
              {page.title}
            </Link>
          );
        }
      }
    }

    return returnLink;
  }

  render() {
    const pages = this.props.pages.filter((page) => {
      return page.showintopmenu;
    });
    return (
      <nav className="navbar navbar-expand-lg">
        <div className="container">
          <a className="navbar-brand" href="/home">
            <img src={logo} alt="" />
          </a>
          <button
            type="button"
            className="navbar-toggler collapsed"
            data-toggle="collapse"
            data-target="#main-navigation"
            aria-expanded="false"
            onClick={this.openNav}
          >
            <span className="navbar-toggler-icon">
              <i className="fa fa-bars" />
            </span>
          </button>
          <div
            className={`navbar-collapse collapse ${this.state.open ? 'show' : 'hide'} `}
            id="main-navigation"
          >
            <ul className="navbar-nav">
              {pages.map(page =>
                <li key={page.url} className="nav-item has-menu open-menu">
                  {this.createLink(page)}
                  {this.createSubpages(page.subpages)}
                </li>
              )}
            </ul>
          </div>
        </div>
      </nav>
    );
  }
}

PageList.propTypes = {
  pages: PropTypes.array.isRequired,
  handlePageChange: PropTypes.func.isRequired,
};

export default withRouter(PageList);
