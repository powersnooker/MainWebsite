import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import { PageList } from './pages.jsx';

// Props
const props = {
  pages: [
    {
      subtitle: 'Welcome to powersnooker',
      tags: 'powersnooker, revolution, psc, coins, PowerSnookerCoin',
      title: 'Home',
      url: 'home',
      subpages: [
        {
          subtitle: 'Welcome to powersnooker',
          tags: 'powersnooker, revolution, psc, coins, PowerSnookerCoin',
          title: 'Home',
          url: 'home',
        },
      ],
    },
  ],
};

  // Context
const compGlobal = shallow(
  <PageList {...props} />
);

describe('<Pages />', () => {
  it('component should render child', () => {
    expect(compGlobal.find('.navbar')).to.have.length(1);
  });
});
