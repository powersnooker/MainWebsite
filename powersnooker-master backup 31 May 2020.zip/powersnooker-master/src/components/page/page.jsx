import React, { Component, PropTypes } from 'react';
import Remarkable from 'remarkable';
import MetaTags from 'react-meta-tags';
import { TwitterTimelineEmbed } from 'react-twitter-embed';
import { Widgets } from '../widgets/widgets.jsx';
import { Accordions } from '../accordions/accordions.jsx';
import ApplyCoins from '../applycoins/applycoins.jsx';
import MailingList from '../mailinglist/mailinglist.jsx';

import './page.scss';

export class Page extends Component {
  printWidgets(page) {
    return (
      <Widgets
        items={Object.prototype.hasOwnProperty.call(page, 'widgets') ?
          page.widgets : []}
        pageName={page.url}
        headings={page.widgetsHeading}
      />
    );
  }


  printMarkDown(markdown) {
    const md = new Remarkable();
    return <div dangerouslySetInnerHTML={{ __html: md.render(markdown) }} />;
  }

  printAccordion(data) {
    return (
      <Accordions
        items={Object.prototype.hasOwnProperty.call(data, 'accordions') ?
        this.props.selected.accordions : []}
        title={Object.prototype.hasOwnProperty.call(data, 'accordionTitle') ?
        this.props.selected.accordionTitle : ''}
      />
    );
  }

  printForm(page) {
    let form = '';

    if (page.url === 'requestapplicationpurchase') {
      form = <ApplyCoins cta="Request Application" type="requestapplication" />;
    } else if (page.url === 'community') {
      form = <MailingList cta="Join Mailing List" type="mailinglist" />;
    }

    return form;
  }

  printSideWidget(page) {
    let widget = '';

    if (page === 'community') {
      widget = (
        <TwitterTimelineEmbed
          sourceType="profile"
          screenName="powersnookeruk"
          options={{ height: 400 }}
        />
      );
    } else {
      widget = (
        <img
          src={Object.prototype.hasOwnProperty.call(this.props.selected, 'sideimage') ?
          this.props.selected.sideimage.fields.file.url : ''}
          alt="text"
        />
       );
    }

    return widget;
  }

  render() {
    return (
      <div>
        <div className="wrapper">
          <MetaTags>
            <title>Powersnooker | {this.props.selected.title}</title>
            <meta name="description" content={this.props.selected.description} />
            <meta property="og:title" content={this.props.selected.title} />
            <meta property="og:image" content="path/to/image.jpg" />
          </MetaTags>
        </div>
        <section className="page-header">
          <div className="container">
            <h1 className="heading"> {this.props.selected.title}</h1>
            {/* <ul className="breadcrumb">
              <li className="breadcrumb-item">
                <a href="/">Home</a>
              </li>
              <li className="breadcrumb-item active">
                <a href="/">{this.props.selected.title}</a>
              </li>
            </ul> */}
          </div>
        </section>

        <section className="container">
          <div className="row">
            <div className="col-lg-8 mt-20">
              <p className="text-normal">{this.props.selected.shortDescription}</p>
              {this.printMarkDown(this.props.selected.description)}
              {this.printForm(this.props.selected)}
            </div>
            <div className="col-lg-4 mt-20">
              <aside className="side-widget">
                <div className="text-center">
                  {this.printSideWidget(this.props.selected.url)}
                </div>
              </aside>
            </div>
          </div>
        </section>
        <div>
          {this.printAccordion(this.props.selected)}
        </div>
        <div className="mt-100">
          {this.printWidgets(this.props.selected)}
        </div>
      </div>
    );
  }
}

Page.propTypes = {
  selected: PropTypes.object,
  widgets: PropTypes.array,
};

export default Page;
