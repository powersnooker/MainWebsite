import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import Page from './page.jsx';

// Props
const props = {
  selected: {
    shortDescription: 'www.bbc.co.uk',
  },
};

  // Context
const compGlobal = shallow(
  <Page {...props} />
);

describe('<Page />', () => {
  it('component should render child', () => {
    expect(compGlobal.find('.wrapper')).to.have.length(1);
  });
});
