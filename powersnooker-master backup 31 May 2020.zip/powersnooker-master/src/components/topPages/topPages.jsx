import React, { Component, PropTypes } from 'react';
import Slider from 'react-slick';

// Styles
import './topPages.scss';

export class TopPages extends Component {
  handleSearch(event) {
    this.props.handleChange(event.target.value);
  }

  printText(page) {
    let text = '';

    if (Object.prototype.hasOwnProperty.call(page, 'hidetextoncarousel')) {
      if (!page.hidetextoncarousel) {
        text = (
          <div>
            <h2>{page.title}</h2>
            <h3>{page.subtitle}</h3>
          </div>
        );
      }
    }

    return text;
  }

  printSlider() {
    const settings = {
      dots: true,
      infinite: true,
      speed: 1000,
      autoplaySpeed: 5000,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: true,
    };

    let slider = '';
    if (this.props.pages.length > 0) {
      slider = (<Slider {...settings} className="bg-light">
        {this.props.pages.map(page =>
          <div
            key={page.url}
            className="slide rev_slider_wrapper fullwidthbanner-container bg-light"
          >
            <a
              className="animation  hidden-xs"
              href={page.redirecturl}
            >
              <div className={`slider-content ${page.sliderTextPos.fields.position}`}>
                {this.printText(page)}
              </div>
              <img
                src={page.bannerimage.fields.file.url}
                alt={page.title}
              />
            </a>
          </div>
        )}
      </Slider>);
    }

    return slider;
  }

  render() {
    return (
      <div className="slider">
        { this.printSlider()}
      </div>
    );
  }
}

TopPages.defaultProps = {
  pages: [],
};

TopPages.propTypes = {
  pages: PropTypes.array,
  handleChange: PropTypes.func,
};

export default TopPages;
