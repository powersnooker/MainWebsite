import React, { Component, PropTypes } from 'react';
import Slider from 'react-slick';
import { Widget } from '../widget/widget.jsx';

import './listings.scss';

export class VideosComp extends Component {

  _printWidgetsTest() {
    const { items } = this.props;
    let widgets = [];
    let settings = {
      dots: true,
      infinite: true,
      speed: 3000,
      autoplaySpeed: 5000,
      slidesToShow: 3,
      slidesToScroll: 3,
      autoplay: true,
    };

    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i
      .test(navigator.userAgent)) {
      settings = {
        dots: true,
        infinite: true,
        speed: 3000,
        autoplaySpeed: 15000,
        slidesToShow: 1,
        slidesToScroll: 1,
      };
    }

    if (items.length > 0) {
      const videos = items.filter(widget => {
        return widget.fields.type === 'videos';
      });
      const video = true;

      if (videos.length > 3) {
        widgets = (
          <Slider {...settings}>
            {videos.map((widget, index) =>
              <div className="slide rev_slider_wrapper">
                <Widget item={widget} isVideo={video} className="slick-slide slide" key={index} />
              </div>
            )}
          </Slider>
        );
      } else {
        widgets = videos.map((widget) =>
          <Widget item={widget} key={widget.sys.id} />
        );
      }
    }

    return widgets;
  }

  render() {
    return (
      <section id="videos" className="bg-light pt-100 pb-100">
        <div className="container">
          <div className="row">
            <div className="col-lg-12 col-xs-12">
              <h2 className="heading text-center">
                {this.props.headings.fields.mainHeading}
                <span className="text-primary">&nbsp; {this.props.headings.fields.shortWord}</span>
                <span className="sub-heading">
                  {this.props.headings.fields.shortText}
                </span>
              </h2>
            </div>
            {this._printWidgetsTest()}
          </div>
        </div>
      </section>
    );
  }
}

VideosComp.propTypes = {
  items: PropTypes.array,
  headings: PropTypes.object,
};

VideosComp.defaultProps = {
  headings: {
    fields: {
      mainHeading: '',
      shortText: '',
      shortWord: '',
    },
  },
};

export default VideosComp;
