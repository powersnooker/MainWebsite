import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import Videos from './listings.jsx';

// Props
const props = {
  item: {
    fields:
    {
      url: 'www.bbc.co.uk',
      image: {
        fields: {
          file: {
            url: 'www.bbc.co.uk',
          },
        },
      },
      message: 'xsdsadsad',
    },
  },
};

  // Context
const compGlobal = shallow(
  <Videos {...props} />
);

describe('<Videos />', () => {
  it('component should render child', () => {
    expect(compGlobal.find('.videos')).to.have.length(1);
  });
});
