import React, { Component } from 'react';

import './gdpr.scss';

class GDPR extends Component {
  constructor(props) {
    super(props);
    this.state = {
      acceptedTerms: false,
    };

    this.saveResponse = this.saveResponse.bind(this);
  }

  saveResponse() {
    sessionStorage.setItem('aceptedcookies', true);
    this.setState({
      acceptedTerms: true,
    });
  }

  printBanner() {
    let selectedMember = '';
    const condition = this.state.acceptedTerms
      || sessionStorage.getItem('aceptedcookies') === 'true';

    if (!condition) {
      selectedMember = (
        <div>
          <div className="modal-backdrop fade show" />
          <div
            className={`modal ${!condition ? 'showMember' : 'hideMember'} fade show`}
          >
            <div className="modal-dialog modal-lg" role="document">
              <div className="modal-content">
                <div className="modal-body">
                  <div className="container-fluid">
                    <div className="row">
                      <div className="col-lg-12">
                        <div className="col-lg-12 pt-40 pb-40 welcome">
                          <h1>Welcome to PowerSnooker.com</h1>
                          <p>
                              Please note that we use cookies to personalise content,
                              to provide social media features and to analyse traffic.
                              We also share information with our social media,
                              advertising and analytics partners.
                              Please confirm whether you accept
                              this by clicking the button below for each of our cookies.
                          </p>
                          <button
                            type="submit"
                            name="submit"
                            className="btn btn-primary"
                            onClick={this.saveResponse}
                          >
                            I Accept
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }
    return selectedMember;
  }

  render() {
    return (
      <div>
        {this.printBanner()}
      </div>
    );
  }
}

export default GDPR;
