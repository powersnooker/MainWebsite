import React, { PropTypes, Component } from 'react';

import './banner.scss';

class Banner extends Component {
  printBanner(banner) {
    let bannerToPrint = '';

    if (banner) {
      bannerToPrint = (
        <div className="bg-primary">
          <div className="container">
            <div className="row">
              <a className="col-lg-12" href={banner.fields.url}>
                <div className="motto">
                  <img
                    src={banner.fields.image.fields.file.url}
                    className="motto-img  d-md-block"
                    alt=""
                  />
                  <p className="motto-text">{banner.fields.message}</p>
                </div>
              </a>
            </div>
          </div>
        </div>
      );
    }

    // print the banner
    return bannerToPrint;
  }

  render() {
    const { banner } = this.props;
    return (
      <div>
        {this.printBanner(banner)}
      </div>
    );
  }
}

Banner.propTypes = {
  banner: PropTypes.object,
};


Banner.defaultProps = {
  banner: {},
};

export default Banner;
