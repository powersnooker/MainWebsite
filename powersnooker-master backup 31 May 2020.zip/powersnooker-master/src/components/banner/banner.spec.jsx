import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import Banner from './banner.jsx';

// Props
const props = {
  banner: {
    fields:
    {
      url: 'www.bbc.co.uk',
      image: {
        fields: {
          file: {
            url: 'www.bbc.co.uk',
          },
        },
      },
      message: 'xsdsadsad',
    },
  },
};

  // Context
const compGlobal = shallow(
  <Banner {...props} />
);

describe('<Banner />', () => {
  it('component should render child', () => {
    expect(compGlobal.find('.banner')).to.have.length(1);
  });
});
