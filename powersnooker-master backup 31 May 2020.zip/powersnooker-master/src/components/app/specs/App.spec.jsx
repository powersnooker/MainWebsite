import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import App from '../App';

describe("component/App", () => {
  it('should mount', () => {
    const comp = shallow(
      <App />
    );

    expect(comp.find('div').length).to.be.least(1);
  });
});
