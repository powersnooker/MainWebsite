import React, { PropTypes, Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import Formsy from 'formsy-react';
import Captcha from 'react-captcha';

import { sendData } from '../../actions/forms.jsx';

import './mailinglist.scss';

class MailingList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      surname: '',
      email: '',
      referral: '',
    };

    this.handleChangeName = this.handleChangeName.bind(this);
    this.handleChangeSurname = this.handleChangeSurname.bind(this);
    this.handleChangeEmail = this.handleChangeEmail.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.state = {
      disabled: true,
    };
  }

  handleChangeName(event) {
    this.setState({ name: event.target.value });
  }

  handleChangeSurname(event) {
    this.setState({ surname: event.target.value });
  }

  handleChangeEmail(event) {
    this.setState({ email: event.target.value });
  }

  handleSubmit() {
    const messageToSend = {
      body: `<h1>New Mailing List Request</h1>
      <p>" ${this.state.name} " " ${this.state.surname} 
      " <br />with email" ${this.state.email} "</p>`,
      name: this.state.name,
      surname: this.state.surname,
      email: this.state.email,
      type: 'Mailing List Application Form',
    };

    this.props.actions.sendData(messageToSend, 'info@powersnooker.com');
  }

  render() {
    return (
      <Formsy onSubmit={this.handleSubmit}>
        <section className="container mt-80">
          <div className="row">
            <div className="col-lg-7 mt-20">
              <h3 className="heading">
                Please Supply your details to join our Mailing List
              </h3>
              <form id="main-contact-form">
                <div className="form-group">
                  <label htmlFor="contact-email">Email</label>
                  <input
                    id="contact-email"
                    type="email"
                    className="form-control"
                    name="email"
                    onChange={this.handleChangeEmail}
                    required
                    validations="isEmail"
                    validationError="This is not a valid email"
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="contact-number">First Name</label>
                  <input
                    id="contact-surname"
                    type="text"
                    className="form-control"
                    name="surname"
                    onChange={this.handleChangeName}
                    required
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="contact-numberSurname">Last Name</label>
                  <input
                    id="contact-name"
                    type="text"
                    className="form-control"
                    name="name"
                    onChange={this.handleChangeSurname}
                    required
                  />
                </div>
                <input type="hidden" name="toSend" value="info@powersnooker.com" />
                <div className="form-group">
                  <label className="custom-control custom-checkbox" htmlFor="tnc">
                    <input type="checkbox" id="tnc" className="custom-control-input" required />
                    <span className="custom-control-indicator" />
                    <span className="custom-control-description">
                      From time to time Power Snooker would like to
                      contact you and send information we think you
                      might be interested in.
                    </span>
                  </label><br /> <br />
                  <p>
                    Please tick the box
                    below to confirm you are happy for us to do so, please
                    note that you can opt out of this at any time throughout our service.
                  </p>
                </div>
                {this.props.formsState}
                <Captcha
                  sitekey="6Lea5ksUAAAAAPESIL1BNi_CI9g1DRo9VxDZV48E"
                  lang="en"
                  theme="light"
                  type="image"
                  callback={(value) => {
                    if (value) {
                      this.setState({
                        disabled: false,
                      });
                    }
                  }}
                />
                <button
                  type="submit"
                  name="submit"
                  className="btn btn-primary"
                  disabled={this.state.disabled}
                >
                  {this.props.cta}
                </button>
              </form>
            </div>
          </div>
        </section>
      </Formsy>
    );
  }
}

MailingList.propTypes = {
  services: PropTypes.array.isRequired,
  pages: PropTypes.array.isRequired,
  extraInfo: PropTypes.object.isRequired,
  people: PropTypes.object.isRequired,
  formsState: PropTypes.object,
  actions: PropTypes.object,
  type: PropTypes.string,
  cta: PropTypes.string,
};


MailingList.defaultProps = {
  actions: () => { },
  formsState: '',
};

const mapDispatchToProps = (dispatch) => {
  return { actions: bindActionCreators({ sendData }, dispatch) };
};


const mapStateToProps = (state) => {
  return {
    formsState: (Object.prototype.hasOwnProperty.call(state.forms, 'status'))
    ? state.forms.status : '',
  };
};


export default connect(mapStateToProps,
  mapDispatchToProps)(MailingList);
