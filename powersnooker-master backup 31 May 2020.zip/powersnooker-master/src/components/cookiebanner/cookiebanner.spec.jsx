import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import Cookiebanner from './cookiebanner.jsx';

// Props
const props = {
  banner: {
    fields:
    {
      url: 'www.bbc.co.uk',
      image: {
        fields: {
          file: {
            url: 'www.bbc.co.uk',
          },
        },
      },
      message: 'xsdsadsad',
    },
  },
};

  // Context
const compGlobal = shallow(
  <Cookiebanner {...props} />
);

describe('<Cookiebanner />', () => {
  it('component should render child', () => {
    expect(compGlobal.find('.cookiebanner')).to.have.length(1);
  });
});
