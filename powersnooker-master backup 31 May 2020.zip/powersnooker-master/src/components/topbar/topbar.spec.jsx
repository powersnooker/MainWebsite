import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import TopBar from './topbar.jsx';

// Props
const props = {
  items: {
    telephonenumber: {
      value: '',
    },
    ico: {
      value: '',
      link: '',
    },
    emailaddress: {
      link: '',
    },
    communityurl: {
      link: '',
      value: '',
    },
  },
};

  // Context
const compGlobal = shallow(
  <TopBar {...props} />
);

describe('<TopBar />', () => {
  it('component should render child', () => {
    expect(compGlobal.find('.topbar-wrapper')).to.have.length(1);
    expect(compGlobal.find('.topbar')).to.have.length(2);
  });
});
