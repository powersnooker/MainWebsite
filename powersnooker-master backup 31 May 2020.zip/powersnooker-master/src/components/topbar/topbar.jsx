import React, { Component, PropTypes } from 'react';

// Styles
import './topbar.scss';

export class TopBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      items: props.items,
    };
  }

  render() {
    const { items } = this.props;

    let data = null;
    if (Object.prototype.hasOwnProperty.call(items, 'telephonenumber')) {
      data = (
        <div className="topbar-wrapper hidden-xs">
          <div className="container">
            <div className="topbar">
              <div>
                <span
                  data-toggle="modal"
                  data-target="#cart-modal"
                  dangerouslySetInnerHTML={{ __html: items.telephonenumber.value }}
                />
              </div>
              <div>
                <ul className="topbar-widgets">
                  <li>
                    <a
                      href={items.ico.link}
                    >
                      {items.ico.value}
                    </a>
                  </li>
                  <li>
                    <a
                      href={`mailto:${items.emailaddress.link}`}
                    >
                      {items.emailaddress.value}
                    </a>
                  </li>
                  <li>
                    <a
                      href={items.communityurl.link}
                    >
                      {items.communityurl.value}
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      );
    }

    return data;
  }
}

TopBar.propTypes = {
  items: PropTypes.object,
};

TopBar.defaultProps = {
  items: {
  },
};


export default TopBar;
