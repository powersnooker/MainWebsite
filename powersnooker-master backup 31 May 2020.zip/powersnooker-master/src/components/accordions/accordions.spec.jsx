import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import Accordions from './accordions.jsx';

// Props
const props = {
  items: [

  ],
};

  // Context
const compGlobal = shallow(
  <Accordions {...props} />
);

describe('<Accordions />', () => {
  it('component should render child', () => {
    expect(compGlobal.find('.accordions')).to.have.length(1);
  });
});
