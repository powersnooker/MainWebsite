import React, { PropTypes, Component } from 'react';
import Accordion from 'react-responsive-accordion';
import Remarkable from 'remarkable';

import './accordions.scss';

export class Accordions extends Component {
  constructor(props, context) {
    super(props, context);

    this.handleSelect = this.handleSelect.bind(this);

    this.state = {
      activeKey: '1',
    };
  }

  handleSelect(activeKey) {
    this.setState({ activeKey });
  }

  printMarkDown(markdown) {
    const md = new Remarkable();
    return <div dangerouslySetInnerHTML={{ __html: md.render(markdown) }} />;
  }


  render() {
    return (
      <section className="container">
        <div className="row">
          <div className="col-lg-8">
            <h2 className="heading"> <span className="text-primary">{this.props.title}</span></h2>
            <div role="tablist" aria-multiselectable="true" className="accordion-2">
              <Accordion >
                {this.props.items.map((item) =>
                  <div data-trigger={item.fields.name}>
                    {this.printMarkDown(item.fields.contentLong)}
                  </div>
                )}
              </Accordion>
            </div>
          </div>
        </div>
      </section>
    );
  }
}

Accordions.propTypes = {
  items: PropTypes.array.isRequired,
  title: PropTypes.string.isRequired,
};

Accordions.defaultProps = {
  items: [],
  title: '',
};

export default Accordion;
