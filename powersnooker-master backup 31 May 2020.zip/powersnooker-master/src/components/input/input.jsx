import React from 'react';
import PropTypes from 'prop-types';
import { withFormsy } from 'formsy-react';

import './input.scss';

export class Input extends React.Component {
  static propTypes = {
    name: PropTypes.string.isRequired,
    setValue: PropTypes.func.isRequired,
    getValue: PropTypes.func.isRequired,
    getErrorMessage: PropTypes.func.isRequired,
    title: PropTypes.string.isRequired,
    type: PropTypes.string.isRequired,
    required: PropTypes.bool.isRequired,
    isFormSubmitted: PropTypes.bool.isRequired,
    label: PropTypes.string.isRequired,
  }

  constructor(props) {
    super(props);
    this.changeValue = this.changeValue.bind(this);
  }

  changeValue(event) {
    this.props.setValue(event.currentTarget.value);
  }

  render() {
    // An error message is returned only if the component is invalid
    const errorMessage = this.props.getErrorMessage();
    return (
      <div className="form-group row">
        <label
          htmlFor={this.props.name}
          className="col-md-5 control-label"
        >
          {this.props.label}
        </label>
        <div className="col-md-7">
          <input
            id={this.props.name}
            InputLabelProps={{
              shrink: true,
            }}
            label={this.props.title}
            value={this.props.getValue()}
            onChange={this.changeValue}
            name={this.props.name}
            required={this.props.required}
            className="form-control"
            fullWidth
          />
          <div
            className={(typeof this.props.getValue() === 'undefined'
            || this.props.getValue() === '')
            && (this.props.required && this.props.isFormSubmitted()) ? 'cerror' : 'hide'}
          >
            The field is Required
          </div>
          <div className={errorMessage ? 'cerror' : 'hide'}>
            {errorMessage}
          </div>
        </div>
      </div>
    );
  }
}

export default withFormsy(Input);
