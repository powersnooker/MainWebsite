import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import Videos from './listings.jsx';

// Props
const props = {
  items: [],
};

  // Context
const compGlobal = shallow(
  <Videos {...props} />
);

describe('<Services />', () => {
  it('component should render child', () => {
    expect(compGlobal.find('.services')).to.have.length(1);
  });
});
