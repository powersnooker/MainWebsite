import React, { Component, PropTypes } from 'react';
import { Widget } from '../widget/widget.jsx';

import './listings.scss';

export class ServicesComp extends Component {
  printWidgets() {
    const { items } = this.props;
    return (
      items.filter(widget => {
        return widget.fields.type === 'services';
      }).map((widget, index) =>
        <Widget item={widget} key={index} />
      )
    );
  }

  render() {
    return (
      <section className="bg-light pt-100 pb-100">
        <div className="container pb-100">
          <div className="row">
            <div className="col-lg-12">
              <h2 className="heading text-center">
                {this.props.headings.fields.mainHeading}
                <span className="text-primary">&nbsp;{this.props.headings.fields.shortWord}</span>
                {/* <span className="sub-heading">
                 Below is a small range of our products
                </span> */}
              </h2>
            </div>
            {this.printWidgets()}
          </div>
        </div>
      </section>
    );
  }
}

ServicesComp.propTypes = {
  items: PropTypes.array,
  headings: PropTypes.object,
};

ServicesComp.defaultProps = {
  headings: {
    fields: {
      mainHeading: '',
      shortText: '',
      shortWord: '',
    },
  },
};

export default ServicesComp;
