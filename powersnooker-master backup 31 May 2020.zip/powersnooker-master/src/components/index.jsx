export { default as Pages } from './pages/pages.jsx';
export { default as PageDetails } from './pageDetails/pageDetails.jsx';
