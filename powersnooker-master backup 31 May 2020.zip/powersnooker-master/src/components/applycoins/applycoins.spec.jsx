import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import ApplyCoins from './applycoins.jsx';

// Props
const props = {
  items: [

  ],
};

  // Context
const compGlobal = shallow(
  <ApplyCoins {...props} />
);

describe('<ApplyCoins />', () => {
  it('component should render child', () => {
    expect(compGlobal.find('.applycoins')).to.have.length(1);
  });
});