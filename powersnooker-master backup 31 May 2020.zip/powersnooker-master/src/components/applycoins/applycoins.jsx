import React, { PropTypes, Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import Formsy from 'formsy-react';
import If from 'babel-plugin-jsx-control-statements';
import Captcha from 'react-captcha';
import Input from '../input/input.jsx';
import Select from '../select/select.jsx';
import { sendData } from '../../actions/forms.jsx';

import './applycoins.scss';

class ApplyCoins extends Component {
  constructor(props) {
    super(props);
    this.state = {
      step: 0,
      data: {},
      disabled: true,
      concent: false,
      finished: false,
    };

    this.handleSubmit = this.handleSubmit.bind(this);
    this.boxticked = this.boxticked.bind(this);
  }

  boxticked() {
    this.setState({
      concent: true,
    });
  }

  handleSubmit(data) {
    const messageToSend = {
      body: `<h1>New ICO Application Request</h1>
      <p>" ${data.name} " " . ${data.surname}  . " from " . ${data.referral}  .  
      " <br />with email" .${data.email} . " ${JSON.stringify(data)}</p>`,
      name: data.name,
      surname: data.surname,
      email: data.email,
      type: 'ICO Application Form',
    };
    this.props.actions.sendData(messageToSend, 'ico@powersnooker.com');
    this.setState({
      finished: true,
    });
    document.body.scrollTop = document.documentElement.scrollTop = 0;
  }

  render() {
    return (
      <div>
        <If condition={!this.state.finished}>
          <section>
            <p>
              Thank you for registering your interest to purchase PowerSnookerCoins.
              Before you go any further please ensure that:
            </p>
            <ul>
              <li>
                You have created your Waves wallet. You can follow the simple guidelines
                on our <a href="https://www.powersnooker.com/waveswalletguide">web site</a>
              </li>
              <li>
                You have scanned copy of your passport or your driving license (mandatory)
                  </li>
              <li>
                You have scanned copy of a utility bill which is not more than three months old.
                (mandatory)
                  </li>
            </ul>
            <h2 className="heading">
              Please Supply your details
            </h2>
            <Formsy
              onValidSubmit={this.handleSubmit}
              onInvalid={this.validateForm}
              noValidate
              className="form-horizontal"
            >
              <div className="row">
                <div className="col-lg-10 mt-20">
                  <div className="form-group">
                    <Input
                      label="Email"
                      name="email"
                      title="test"
                      type="email"
                      id="contact-email"
                      className="form-control"
                      required
                      validations="isEmail"
                      validationError="This is not a valid email"
                    />
                  </div>
                  <div className="form-group">
                    <Input
                      label="First Name"
                      name="name"
                      title="test"
                      type="text"
                      id="name"
                      className="form-control"
                      required
                    />
                  </div>
                  <div className="form-group">
                    <Input
                      label="Middle Name"
                      name="middlename"
                      title="test"
                      type="text"
                      id="middlename"
                      className="form-control"
                    />
                  </div>
                  <div className="form-group">
                    <Input
                      label="Surname"
                      name="surname"
                      title="test"
                      type="text"
                      id="surname"
                      className="form-control"
                      required
                    />
                  </div>
                  <div className="form-group">
                    <Input
                      label="Referral"
                      name="referral"
                      title="test"
                      type="text"
                      id="referral"
                      className="form-control"
                    />
                  </div>
                  <div className="form-group">
                    <Input
                      label="Phone Number"
                      name="phone"
                      title="test"
                      type="text"
                      id="phone"
                      className="form-control"
                      validations="isNumeric"
                      validationError="This is not a valid telephone number"
                      required
                    />
                  </div>
                  <div className="form-group">
                    <Input
                      label="Date of Birth"
                      name="dob"
                      title="test"
                      type="text"
                      id="dob"
                      className="form-control"
                      required
                    />
                  </div>
                </div>
                <div className="col-lg-10 mt-20">
                  <div className="form-group">
                    <Input
                      label="House Name"
                      name="housename"
                      title="test"
                      type="text"
                      id="housename"
                      className="form-control"
                    />
                  </div>
                  <div className="form-group">
                    <Input
                      label="House Number"
                      name="housenumber"
                      title="test"
                      type="text"
                      id="phone"
                      className="form-control"
                    />
                  </div>
                  <div className="form-group">
                    <Input
                      label="Street"
                      name="street"
                      title="test"
                      type="text"
                      id="street"
                      className="form-control"
                      required
                    />
                  </div>
                  <div className="form-group">
                    <Input
                      label="City"
                      name="city"
                      title="test"
                      type="text"
                      id="city"
                      className="form-control"
                      required
                    />
                  </div>
                  <div className="form-group">
                    <Input
                      label="Country"
                      name="country"
                      title="test"
                      type="text"
                      id="country"
                      className="form-control"
                      required
                    />
                  </div>
                  <div className="form-group">
                    <Input
                      label="PostCode/Zip code"
                      name="postcode"
                      title="test"
                      type="text"
                      id="postcode"
                      className="form-control"
                      required
                    />
                  </div>
                </div>
                <div className="col-lg-10 mt-20">
                  <div className="form-group">
                    <Input
                      label="Number of PowerSnookerCoins to purchase"
                      name="bitcoinsnum"
                      title="test"
                      type="text"
                      id="bitcoinsnum"
                      className="form-control"
                      required
                    />
                  </div>
                  <div className="form-group">
                    <Input
                      label="Waves Wallet Address"
                      name="waveswaletaddress"
                      title="test"
                      type="text"
                      id="wwa"
                      className="form-control"
                      required
                    />
                  </div>
                  <div className="form-group">
                    <Select
                      name="paymentmethod"
                      required
                      handleSubmit={this.handleChange}
                      label="Payment method"
                      options={[
                        { value: 'Payment method' },
                        { value: 'BTC' },
                        { value: 'ETH' },
                        { value: 'STERLING' },
                        { value: 'EURO' },
                        { value: 'None of the above' },
                      ]}
                    />
                  </div>
                  <div className="form-group">
                    <Select
                      name="originmethod"
                      required
                      handleSubmit={this.handleChange}
                      label="Origin of funds"
                      options={[
                        { value: 'Origin of funds' },
                        { value: 'Borrowing from bank' },
                        { value: 'Borrowing from family member or friend' },
                        { value: 'Business' },
                        { value: 'From Savings' },
                      ]}
                    />
                  </div>
                  <div className="form-group">
                    <label className="custom-control custom-checkbox" htmlFor="tnc">
                      <input
                        type="checkbox"
                        id="tnc"
                        name="concent"
                        className="custom-control-input"
                        required
                        onClick={this.boxticked}
                      />
                      <span className="custom-control-indicator" />
                      <span
                        className={`custom-control-description 
                        ${this.state.concent ? '' : 'cerror'}`}
                      >
                        Please tick this box to confirm you agree
                        to Power Snooker’s terms and conditions.
                          </span>
                    </label><br /><br />
                    <p>
                      We will use your personal data to help create your account and
                      to support any other services you
                      may use. Please have a look at our privacy policy for more
                      information on how we use your data.
                      Please note your consent to our terms and conditions is
                      required in order for us to provide you with
                      our service.
                        </p>
                  </div>
                  {this.props.formsState}
                  <Captcha
                    sitekey="6Lea5ksUAAAAAPESIL1BNi_CI9g1DRo9VxDZV48E"
                    lang="en"
                    theme="light"
                    type="image"
                    callback={(value) => {
                      if (value) {
                        this.setState({
                          disabled: false,
                        });
                      }
                    }}
                  />
                  <button
                    type="submit"
                    name="submit"
                    className="btn btn-primary"
                    disabled={this.state.disabled && this.state.concent}
                  >
                    {this.props.cta}
                  </button>
                </div>
              </div>
            </Formsy>
          </section>
        </If>
        <If condition={this.state.finished}>
          <section>
            <h2>Thank you</h2>
            <p>
            Thank you for completing the preliminary
            application and we will revert back to you within 24 hours
            </p>
          </section>
        </If>
      </div>
    );
  }
}

ApplyCoins.propTypes = {
  services: PropTypes.array.isRequired,
  pages: PropTypes.array.isRequired,
  extraInfo: PropTypes.object.isRequired,
  people: PropTypes.object.isRequired,
  formsState: PropTypes.object,
  actions: PropTypes.object,
  type: PropTypes.string,
  cta: PropTypes.string,
};


ApplyCoins.defaultProps = {
  actions: () => { },
  formsState: '',
};

const mapDispatchToProps = (dispatch) => {
  return { actions: bindActionCreators({ sendData }, dispatch) };
};


const mapStateToProps = (state) => {
  return {
    formsState: (Object.prototype.hasOwnProperty.call(state.forms, 'status'))
      ? state.forms.status : '',
  };
};


export default connect(mapStateToProps,
  mapDispatchToProps)(ApplyCoins);
