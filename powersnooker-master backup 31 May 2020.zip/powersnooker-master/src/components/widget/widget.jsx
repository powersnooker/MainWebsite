import React, { Component, PropTypes } from 'react';
import LazyLoad from 'react-lazyload';
import './widget.scss';


export class Widget extends Component {
  printImage(item) {
    let image = '';

    if (Object.prototype.hasOwnProperty.call(item, 'fields')) {
      if (Object.prototype.hasOwnProperty.call(item.fields, 'youtubeLink')) {
        image = (
          <LazyLoad height={200} offset={100}>
            <iframe
              width="560" height="315" src={`https://www.youtube.com/embed/${item.fields.youtubeLink}`}
              frameBorder="0" className="video" allowFullScreen
            />
          </LazyLoad>
        );
      } else if (Object.prototype.hasOwnProperty.call(item.fields, 'image')) {
        if (Object.prototype.hasOwnProperty.call(item.fields.image, 'fields')) {
          image = (
            <LazyLoad height={200} offset={100}>
              <img
                src={item.fields.image.fields.file.url}
                className="img-fluid course-img" alt=""
              />
            </LazyLoad>
          );
        }
      }
    }

    return image;
  }

  render() {
    const { item } = this.props;
    return (
      <div className={`${this.props.isVideo ? 'col-lg-12 col-xs-12' : 'col-lg-4'}`}>
        <div className="card course-card">
          <a href={item.fields.link}>
            <div className="course-head">
              {this.printImage(item)}
            </div>
            <div className="course-detail">
              <h4> {item.fields.name}</h4>
              <p
                dangerouslySetInnerHTML={{ __html: item.fields.content }}
              />
            </div>
          </a>
        </div>
      </div>
    );
  }
}

Widget.propTypes = {
  item: PropTypes.object,
  isVideo: PropTypes.boolean,
};

Widget.propTypes = {
  item: {},
  isVideo: false,
};

export default Widget;
