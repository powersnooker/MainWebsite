import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import Widget from './widget.jsx';

// Props
const props = {
  item: {
    fields:
    {
      url: 'www.bbc.co.uk',
      image: {
        fields: {
          file: {
            url: 'www.bbc.co.uk',
          },
        },
      },
      message: 'xsdsadsad',
    },
  },
};

  // Context
const compGlobal = shallow(
  <Widget {...props} />
);

describe('<Widget />', () => {
  it('component should render child', () => {
    expect(compGlobal.find('.widget')).to.have.length(1);
  });
});
