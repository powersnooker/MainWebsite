import React, { PropTypes, Component } from 'react';
import { Widget } from '../widget/widget.jsx';

import './widgets.scss';

export class Widgets extends Component {
  _printWidgets() {
    const { items } = this.props;
    return (
      items.filter(widget => {
        return (this.props.pageName === 'home')
          ? widget.fields.type === 'default'
          : true;
      }).map((widget, index) =>
        <Widget item={widget} key={index} />
      )
    );
  }

  render() {
    return (
      <section className="bg-light pt-100 pb-100">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <h2 className="heading text-center">
                {this.props.headings.fields.mainHeading}
                <span className="text-primary">
                  &nbsp;{this.props.headings.fields.shortWord}
                </span>
                <span className="sub-heading">
                  {this.props.headings.fields.shortText}
                </span>
              </h2>
            </div>
            {this._printWidgets()}
          </div>
        </div>
      </section>
    );
  }
}

Widgets.propTypes = {
  items: PropTypes.array.isRequired,
  pageName: PropTypes.string.isRequired,
  headings: PropTypes.object,
};

Widgets.defaultProps = {
  items: [],
  pageName: '',
  headings: {
    fields: {
      mainHeading: '',
      shortText: '',
      shortWord: '',
    },
  },
};

export default Widgets;
