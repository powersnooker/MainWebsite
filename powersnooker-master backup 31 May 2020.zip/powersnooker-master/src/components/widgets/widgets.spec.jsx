import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import Widgets from './widgets.jsx';

// Props
const props = {
  item: {
    fields:
    {
      url: 'www.bbc.co.uk',
      image: {
        fields: {
          file: {
            url: 'www.bbc.co.uk',
          },
        },
      },
      message: 'xsdsadsad',
    },
  },
};

  // Context
const compGlobal = shallow(
  <Widgets {...props} />
);

describe('<Widgets />', () => {
  it('component should render child', () => {
    expect(compGlobal.find('.widgets')).to.have.length(1);
  });
});
