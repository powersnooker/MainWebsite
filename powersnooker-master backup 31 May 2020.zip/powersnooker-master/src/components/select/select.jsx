import React from 'react';
import PropTypes from 'prop-types';
import { withFormsy } from 'formsy-react';

import './select.scss';

class Select extends React.Component {
  static propTypes = {
    options: PropTypes.object.isRequired,
    handleSubmit: PropTypes.func.isRequired,
    required: PropTypes.bool,
    setValue: PropTypes.func.isRequired,
    getValue: PropTypes.func.isRequired,
    isFormSubmitted: PropTypes.bool.isRequired,
    name: PropTypes.string.isRequired,
    label: PropTypes.string,
    prelabel: PropTypes.string,
  }

  static defaultProps = {
    required: false,
    label: '',
    prelabel: '',
  }

  constructor(props) {
    super(props);
    this.elements = null;

    this.state = {
      value: undefined,
    };
  }

  changeValue = (event) => {
    this.props.setValue(event.target.value);
    this.setState({ value: event.target.value });
    this.props.handleSubmit(event.target.value);
  }

  renderElement = () => {
    const options = this.props.options.map((option) => (
      <option key={option.value} value={option.value}>
        {option.value}
      </option>
    ));

    return options;
  }


  render() {
    // An error message is returned only if the component is invalid
    const element = this.renderElement();
    return (
      <div className="form-group row">
        <label
          className="col-md-5 control-label"
          htmlFor={this.props.name}
        >
          {this.props.label}
        </label>
        <div className="col-md-7 control-label customselect">
          <select name={this.props.name} onChange={this.changeValue}>
            {element}
          </select>
          <span
            className={typeof this.state.value === 'undefined'
              && (this.props.required && this.props.isFormSubmitted()) ? 'cerror' : 'hide'}
          >
              Please select an option
            </span>
        </div>
      </div>
    );
  }
}

export default withFormsy(Select);
