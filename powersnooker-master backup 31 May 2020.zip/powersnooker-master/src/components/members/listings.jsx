import React, { Component, PropTypes } from 'react';
import Slider from 'react-slick';
import Remarkable from 'remarkable';

import './listings.scss';

export class MembersComp extends Component {
  constructor(p, c) {
    super(p, c);
    this.state = {
      showMember: false,
      selectedMember: null,
    };
    this.showMember = this.showMember.bind(this);
    this.handleClose = this.handleClose.bind(this);
  }

  printMarkDown(markdown) {
    const md = new Remarkable();
    return (!this.props.isHome)
      ? <div dangerouslySetInnerHTML={{ __html: md.render(markdown) }} />
      : '';
  }

  handleClose() {
    this.setState({ showMember: false });
  }

  printSelectedMember() {
    let selectedMember = '';

    if (this.state.selectedMember) {
      selectedMember = (
        <div>
          <div
            className={`fade ${this.state.showMember ? ' modal-backdrop show' : ''}`}
          />
          <div
            className={`modal ${this.state.showMember ? 'showMember' : 'hideMember'}`}
          >
            <div className="modal-dialog modal-lg" role="document">
              <div className="modal-content">
                <button
                  type="button" className="close"
                  onClick={this.handleClose}
                  data-dismiss="modal" aria-label="Close"
                >
                  <span aria-hidden="true">×</span></button>
                <div className="modal-body">
                  <div className="container-fluid">
                    <div className="row">
                      <div className="col-lg-6 pt-40 pb-40">
                        <img
                          src={this.state.selectedMember.fields.image.fields.file.url}
                          className="img-fluid" alt=""
                        />
                      </div>
                      <div className="col-lg-6 pt-40 pb-40">
                        <h4
                          className="heading"
                        >
                          {this.state.selectedMember.fields.name}&nbsp;
                          {this.state.selectedMember.fields.surname}
                        </h4>
                        <p>{this.state.selectedMember.fields.bio}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }

    return selectedMember;
  }

  showMember(event) {
    this.setState({
      selectedMember: event,
      showMember: true,
    });
  }

  printMembers(items) {
    let members = '';
    let settings = {
      dots: true,
      infinite: true,
      speed: 3000,
      autoplaySpeed: 5000,
      slidesToShow: 3,
      slidesToScroll: 3,
      autoplay: true,
    };

    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i
      .test(navigator.userAgent)) {
      settings = {
        dots: true,
        infinite: true,
        speed: 3000,
        autoplaySpeed: 5000,
        slidesToShow: 1,
        slidesToScroll: 1,
      };
    }

    if (items.length > 0) {
      members = (
        <Slider {...settings} id="members">
          {
            items.map((item) =>
              <div className="col-xs-4" key={item.sys.id}>
                <div className="teacher-card">
                  <div className="head">
                    <img src={item.fields.image.fields.file.url} className="img-fluid" alt="" />
                    <div className="info">
                      <ul className="social">
                        <li><a href={item.fields.facebookUrl}>
                          <i className="fa fa-facebook" /></a>
                        </li>
                        <li>
                          <a href={item.fields.twitterUrl}>
                            <i className="fa fa-twitter" />
                          </a>
                        </li>
                        <li><a href={item.fields.linkedinLink}>
                          <i className="fa fa-linkedin" /></a>
                        </li>
                      </ul>
                      <button
                        onClick={() => this.showMember(item)}
                        className="btn btn-primary btn-sm"
                      >
                        View Profile
                        </button>
                    </div>
                  </div>
                  <div className="body">
                    <h5 className="heading">
                      {item.fields.title}&nbsp;
                      {item.fields.name}&nbsp;
                      {item.fields.surname}
                    </h5>
                    <small>{item.fields.position}</small>
                  </div>
                </div>
              </div>
            )}
        </Slider>
      );
    }

    return members;
  }


  render() {
    return (
      <div className="container mt-100">
        <div className="row">
          <div className="col-lg-12">
            <h2 className="heading text-center">{this.props.headings.fields.mainHeading}
              <span className="text-primary">{this.props.headings.fields.shortWord}</span>
              <span className="sub-heading">
                {this.props.headings.fields.shortText}
              </span>
              <span className="icon-divider" />
            </h2>
            {this.printMembers(this.props.items)}
            {this.printSelectedMember()}
          </div>
        </div>
      </div>
    );
  }
}

MembersComp.propTypes = {
  items: PropTypes.array,
  isHome: PropTypes.boolean,
  headings: PropTypes.object,
};

MembersComp.defaultProps = {
  items: [],
  isHome: false,
  headings: {
    fields: {
      mainHeading: '',
      shortText: '',
      shortWord: '',
    },
  },
};

export default MembersComp;
