import React from 'react';
import { expect } from 'chai';
import MembersComp from './listings.jsx';

// Props
const props = {
  selected: {
    shortDescription: 'www.bbc.co.uk',
  },
  test: false,
};

  // Context
const compGlobal = shallow(
  <MembersComp {...props} />
);

describe('<Page />', () => {
  it('component should render child', () => {
    expect(compGlobal.find('.members')).to.have.length(1);
  });
});
