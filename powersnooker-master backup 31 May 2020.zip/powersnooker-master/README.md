# fileloader

# Getting started
```sh
$ npm install
$ npm run dev 
$ npm run test
```

The application will run on localhost:8080

```
# Structure
The main development location is the ```src``` directory:
  - ```src``` The main source directory
  - ```api``` The api for the application


# Deploying
npm run production
