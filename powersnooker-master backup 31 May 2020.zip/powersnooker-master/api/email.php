<?php
   require_once 'ElasticEmailClient.php';
   ElasticEmailClient\ApiClient::SetApiKey("4e395ac5-d396-469d-b1be-1fb272152f1f");
try{
	$input =  json_decode($_POST);
	$url = 'https://api.elasticemail.com/v2/email/send';
	
	if(isset($_POST['body'])){
		$sendTo = $_POST["sendto"];
		$type = $_POST["type"];
		$name = $_POST["name"];
		$surname = $_POST["surname"];
		$email = $_POST["email"];
		$body = $_POST['body'];
		
        $post = array('from' => 'info@powersnooker.com',
		'fromName' => 'Website Form',
		'apikey' => '4e395ac5-d396-469d-b1be-1fb272152f1f',
		'subject' => $type,
		'to' => $sendTo,
		'bodyHtml' =>$body,
		'isTransactional' => false);
		
		$ch = curl_init();
		curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => $post,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
			CURLOPT_SSL_VERIFYPEER => false
        ));
		
        $result=curl_exec ($ch);
        curl_close ($ch);
		$contacts = [$email];
 $EEcontact = new ElasticEmailClient\Contact();
			 $EEcontact->QuickAdd($contacts, $name, $surname);		
 
		
		echo json_encode(array(code => 1 , status => "Your message has been sent"));
	}
}
catch(Exception $ex){
	echo json_encode(array(code => 0, status => $ex->getMessage()));
}
?>